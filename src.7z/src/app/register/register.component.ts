import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  product
  productPrice
  rd1
  productCustomer1
  ch1
  ch2
  ch3
  ch4

  productCustomer=["sintu","raushan" ,"pintu"]

  submit(){


  }

  constructor() { }

  ngOnInit(): void {
  }

}
