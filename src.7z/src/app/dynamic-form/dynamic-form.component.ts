import { Component, OnInit } from '@angular/core';
import { FormGroup, FormArray, FormControl } from '@angular/forms';

@Component({
  selector: 'app-dynamic-form',
  templateUrl: './dynamic-form.component.html',
  styleUrls: ['./dynamic-form.component.css']
})
export class DynamicFormComponent implements OnInit {


   myForm=new FormGroup({
    addrerssInput: new FormArray([])
  })

  addField(){
    this.myForm.controls.addrerssInput.push(new FormControl())
  }

  removeFeild(r){
    this.myForm.controls.addrerssInput.removeAt(r)
  }

  

  constructor() { }

  ngOnInit(): void {
  }

}
