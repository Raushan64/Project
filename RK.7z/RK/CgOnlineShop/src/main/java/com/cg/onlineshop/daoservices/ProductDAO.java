package com.cg.onlineshop.daoservices;

import java.util.ArrayList;
import java.util.List;

import com.cg.onlineshop.beans.Product;

public interface ProductDAO {
	public Product insertProduct(Product product);

	public void updateProduct(Product product);

	public boolean deleteProduct(int productId);

	public List<Product> getAllProducts();

	public Product getProduct(int productId);

	void insertBulkProducts(ArrayList<Product> products);

}
