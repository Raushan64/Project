package com.cg.onlineshop.services;

import java.util.ArrayList;
import java.util.List;
import com.cg.onlineshop.beans.Product;
import com.cg.onlineshop.daoservices.ProductDAO;
import com.cg.onlineshop.daoservices.ProductDAOImpl;
import com.cg.onlineshop.exceptions.ProductDetailsNotFoundException;

public class ProductCatlogServicesImpl implements ProductCatlogServices {

	private ProductDAO productDAO = new ProductDAOImpl();
	
	
	

	public Product acceptProductDetails(Product product) {

		return productDAO.insertProduct(product);
	}
	
	

	public List<Product> getAllProductDetails() {

		return productDAO.getAllProducts();
	}
	
	

	public Product getProductDetails(int productId) throws ProductDetailsNotFoundException {
		
		Product p=productDAO.getProduct(productId);
		if(p==null) {
			throw new  ProductDetailsNotFoundException("ProductDetailsNotFound");
		}
		return productDAO.getProduct(productId);
	}
	
	
	

	public void acceptBulkProductsDetails(ArrayList<Product> products) {
		
		productDAO.insertBulkProducts(products);
	

	}
	
	
	

	public boolean removeProdcutDetails(int productId) {
		
	return	productDAO.deleteProduct(productId);

	}

}
