package com.cg.onlineshop.main;

import java.util.ArrayList;
import java.util.List;

import com.cg.onlineshop.beans.Product;
import com.cg.onlineshop.exceptions.ProductDetailsNotFoundException;
import com.cg.onlineshop.services.ProductCatlogServices;
import com.cg.onlineshop.services.ProductCatlogServicesImpl;

public class MainClass {

	private static ProductCatlogServices productService = new ProductCatlogServicesImpl();

	public static void main(String[] args) {
		
		ArrayList<Product> productList=new ArrayList<>();

		Product product = new Product(100, 50000, 1000, "product is good", "shooes");
		Product product1 = new Product(102, 60000, 2000, "product is  not good", "shirts");
		Product product2 = new Product(103, 70000, 3000, "product is good", "mobile");
		
		productList.add(product1);
		productList.add(product2);
		productList.add(product);

		/*
		 * insert Product
		 */
		Product productDetails = productService.acceptProductDetails(product);
		System.out.println(productDetails);
		

		/*
		 * get All Product Details
		 * Using Java8 forEach() with Lambda Expression
		 */

		List<Product> listOfProducts = productService.getAllProductDetails();
		System.out.println(listOfProducts);
		
		listOfProducts.forEach((products) -> System.out.println(products));
		
		

		/*
		 * get the Product based on productId
		 */
		try {
			System.out.println(productService.getProductDetails(product.getProductId()));

		} catch (ProductDetailsNotFoundException e) {

			e.printStackTrace();
		}
		
		

		/*
		 *    remove product
		 */
		System.out.println(productService.removeProdcutDetails(product.getProductId()));
		
		/*
		 * 	Add multiple product details
		 * 
		 */
		
		productService.acceptBulkProductsDetails(productList);
		
		List<Product> listOfProducts1 = productService.getAllProductDetails();
		System.out.println(listOfProducts1);

	}
}
