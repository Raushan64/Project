package com.cg.onlineshop.services;

import java.util.ArrayList;
import java.util.List;

import com.cg.onlineshop.beans.Product;
import com.cg.onlineshop.exceptions.ProductDetailsNotFoundException;

public interface ProductCatlogServices {
	public Product acceptProductDetails(Product product);
	public List<Product> getAllProductDetails();
	public Product getProductDetails(int productId)
			throws ProductDetailsNotFoundException;
	public void acceptBulkProductsDetails(ArrayList<Product> products);
	public boolean removeProdcutDetails(int productId);
}
