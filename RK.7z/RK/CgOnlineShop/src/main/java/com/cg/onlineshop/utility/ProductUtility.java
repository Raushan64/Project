package com.cg.onlineshop.utility;

import java.util.HashMap;
import java.util.Map;

import com.cg.onlineshop.beans.Product;

public class ProductUtility {

	public static Map<Integer, Product> map = new HashMap<>();
	

	
	

}
