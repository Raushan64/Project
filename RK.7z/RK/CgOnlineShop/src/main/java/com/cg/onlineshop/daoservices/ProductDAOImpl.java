package com.cg.onlineshop.daoservices;

import java.util.ArrayList;
import java.util.List;


import com.cg.onlineshop.beans.Product;
import com.cg.onlineshop.utility.ProductUtility;

public class ProductDAOImpl implements ProductDAO {



	public Product insertProduct(Product product) {

		ProductUtility.map.put(product.getProductId(), product);
		return ProductUtility.map.get(product.getProductId());

	}
	
	
	

	public void updateProduct(Product product) {
		ProductUtility.map.put(product.getProductId(), product);
	}

	
	
	
	
	public boolean deleteProduct(int productId) {

		if (ProductUtility.map.containsKey(productId)) {
			
			ProductUtility.map.remove(productId);
			
			System.out.println(ProductUtility.map);
			
			return true;
		} 
			
			return false;
		
	}
	
	

	public List<Product> getAllProducts() {

		ArrayList<Product> list = new ArrayList<Product>(ProductUtility.map.values());

		/*
		 * List<Product> listofProducts = ProductUtility.map.values().stream()
		 * .collect(Collectors.toList());
		 */

		return list;
	}
	
	
	

	public Product getProduct(int productId) {

		return ProductUtility.map.get(productId);

	}
	
	
	

	public void insertBulkProducts(ArrayList<Product> products) {

		for (Product product : products) {
			ProductUtility.map.put(product.getProductId(), product);

		}
		System.out.println(ProductUtility.map);

	}

}
