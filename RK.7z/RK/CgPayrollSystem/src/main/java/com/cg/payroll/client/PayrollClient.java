package com.cg.payroll.client;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;
import com.cg.payroll.services.PayrollServices;

public class PayrollClient {

	@SuppressWarnings("resource")
	public static void main(String[] args) {

		BankDetails bankDetails = new BankDetails(1634, "SBI", "IFSC00SBI");
		
		Salary salary = new Salary(17000, 10000, 1000, 10000, 20000, 200, 1000, 2000, 100, 600000, 44246);
		
		Associate associate = new Associate(131, "srinu", "velugu", "IT", "Software Engineer", "AUTP900A","srinu@gmail.com", bankDetails, salary);

		ApplicationContext ctx = new ClassPathXmlApplicationContext("applicationContext.xml");
		
		PayrollServices payrollServices = (PayrollServices) ctx.getBean("payrollServiceImpl");

		

		
		
		
		try {
			System.out.println(payrollServices.acceptAssociateDetails(associate));

		} catch (PayrollServicesDownException e) {

			e.printStackTrace();
		}
		
		
		
		
		

		try {
			List<Associate> associateList = payrollServices.getAllAssociatesDetails();

			associateList.forEach((associates) -> System.out.println(associates));

		} catch (PayrollServicesDownException e) {

			e.printStackTrace();
		}
		
		
		

		try {
			System.out.println(payrollServices.getAssociateDetails(associate.getAssociateID()));

		} catch (AssociateDetailsNotFoundException | PayrollServicesDownException e) {

			e.printStackTrace();
		}

	}

}
