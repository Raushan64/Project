package com.cg.payroll.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;

@Service
public class PayrollServiceImpl implements PayrollServices {
	
	
	@Autowired
	AssociateDAO associateDAO;
	
	
	public Associate acceptAssociateDetails(Associate associate) throws PayrollServicesDownException {
		
		  if(associateDAO.save(associate)==null) { throw new
		  PayrollServicesDownException("PayrollServices is Down"); }
		 
		return associateDAO.save(associate);
	}

	
	public int calculateNetSalary(int associateId)
			throws AssociateDetailsNotFoundException, PayrollServicesDownException {
		
		
		return 0;
	}
	
	
	public Associate getAssociateDetails(int associateId)
			throws AssociateDetailsNotFoundException, PayrollServicesDownException {
		
		
		Associate associate=associateDAO.findOne(associateId).orElseThrow(()->new PayrollServicesDownException("PayrollServices is Down"));
		
		if(associateId!=associate.getAssociateID()) {
			throw new AssociateDetailsNotFoundException("AssociateDetailsNotFound");
		}
		return associate;
				
	
	
	}
	

	public List<Associate> getAllAssociatesDetails() throws PayrollServicesDownException {
		
	if(associateDAO.findAll()==null) {
		
		throw new PayrollServicesDownException("PayrollServices is Down");
	}
		return associateDAO.findAll();
	}
}
