package com.cg.payroll.daoservices;
import java.util.List;
import java.util.Optional;

import com.cg.payroll.beans.Associate;

public interface AssociateDAO{
	Associate save(Associate associate);
	boolean update(Associate associate);
	Optional<Associate> findOne(int associateId) ;
	List <Associate>  findAll();
}