package com.cg.payroll.daoservices;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.utils.PayrollUtils;


@Repository
public class AssociateDAOImpl  implements AssociateDAO {

	
	
	
	public Associate save(Associate associate) {
		
		
		associate.setAssociateID(PayrollUtils.getASSOCIATE_ID_COUNTER());
		PayrollUtils.associates.put(associate.getAssociateID(),associate);
		
		return PayrollUtils.associates.get(associate.getAssociateID());
	}
	
	
	
	public boolean update(Associate associate) {
		return false;
	}

	public Optional<Associate> findOne(int associateId) {
		
		
		Associate associate=PayrollUtils.associates.get(associateId);
		Optional<Associate> optional = Optional.of(associate);
		
		return optional;
	}
	
	
	

	public List<Associate> findAll() {
		
		
		ArrayList<Associate> listOfAsscoAssociates=new ArrayList<>(PayrollUtils.associates.values() );
		
		return listOfAsscoAssociates;
	}

}