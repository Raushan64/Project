import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-emi-calculator',
  templateUrl: './emi-calculator.component.html',
  styleUrls: ['./emi-calculator.component.css']
})
export class EmiCalculatorComponent implements OnInit {

  principalAmount
  ROI
  Tenue

  monthEMI
  totalAmount
  interestAmount

  calculate(){
    this.interestAmount = (this.principalAmount*this.ROI*this.Tenue)/100;
    this.totalAmount = this.principalAmount + this.interestAmount;
    this.monthEMI= this.totalAmount/(this.Tenue*12);
 }
 

  constructor() { }

  ngOnInit(): void {
  }

}
