import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-category-product',
  templateUrl: './category-product.component.html',
  styleUrls: ['./category-product.component.css']
})
export class CategoryProductComponent implements OnInit {
  
  category =["electronic", "grocery"]
  product

  electronic =["television", "laptop", "phone"]
  grocery=["soap", "powder"]
  
  
  totalPrice
  quanty
  
  c
  p

  calculate(){
     if(this.product=='television')
       this.totalPrice=this.quanty*20000
       else if (this.product =='laptop')
       this.totalPrice=this.quanty*30000
       else if (this.product =='phone')
       this.totalPrice=this.quanty*10000
       else if (this.product =='soap')
       this.totalPrice=this.quanty*40
       else if (this.product =='powder')
       this.totalPrice=this.quanty*90

  }

  clear(){
    this.quanty='';
    this.totalPrice='';
    this.electronic=[];
    this.grocery=[];

    
  }

  constructor() { }

  ngOnInit(): void {
  }

}
