import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-todo',
  templateUrl: './todo.component.html',
  styleUrls: ['./todo.component.css']
})
export class TodoComponent implements OnInit {

  skills = [];
  s

  Add(){

    this.skills.push(this.s);
  }

   remove(a){
    this.skills.splice(a,1)
   }

  constructor() { }

  ngOnInit(): void {
  }

}
