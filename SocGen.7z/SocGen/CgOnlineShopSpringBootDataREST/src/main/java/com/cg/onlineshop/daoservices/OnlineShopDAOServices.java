package com.cg.onlineshop.daoservices;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import com.cg.onlineshop.beans.Product;

@RepositoryRestResource(collectionResourceRel="products" , path="products")
public interface OnlineShopDAOServices extends PagingAndSortingRepository<Product, Integer>{
	/*public void insertProduct(Product product);
	public void updateProduct(Product product);
	public void deleteProduct(int productId);
	public ArrayList<Product> getAllProducts();
	public Product getProduct(int productId);
	void insertBulkProducts(ArrayList<Product>products);*/
	
	@Query(value="select p from Product p where p.price= :price")
	List<Product> findByPrice(@Param("price") int price);
	

	@Transactional
	@Procedure(value=" call sp_getProductDetailsByName(:productName)")
	List<Product>findByName(@Param("productName")String productName);
	
	
	
}
