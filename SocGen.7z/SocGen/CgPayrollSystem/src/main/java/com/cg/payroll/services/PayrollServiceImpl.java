package com.cg.payroll.services;
import java.util.List;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;
public class PayrollServiceImpl  implements PayrollServices{
	public Associate acceptAssociateDetails(Associate associate) throws PayrollServicesDownException {
		return null;
	}
	public int calculateNetSalary(int associateId)
			throws AssociateDetailsNotFoundException, PayrollServicesDownException {
		return 0;
	}
	public Associate getAssociateDetails(int associateId)
			throws AssociateDetailsNotFoundException, PayrollServicesDownException {
		return null;
	}
	public List<Associate> getAllAssociatesDetails() throws PayrollServicesDownException {
		return null;
	}
}
