package com.cg.onlineshop.services;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.onlineshop.beans.Product;
import com.cg.onlineshop.daoservices.ProductDAO;
import com.cg.onlineshop.exceptions.ProductDetailsNotFoundException;

@Service(value="productCatlogServices")
public class ProductCatlogServicesImpl implements ProductCatlogServices{
	@Autowired
	private ProductDAO productDAO;
	public Product acceptProductDetails(Product product) {
		productDAO.save(product);
		return product;
	}
	public List<Product> getAllProductDetails() {
		return productDAO.findAll();
	}
	public Product getProductDetails(int productId) throws ProductDetailsNotFoundException {
		Optional<Product> optional = productDAO.findById(productId);
		return optional.orElseThrow(()->new ProductDetailsNotFoundException("Product details not found with Id "+productId));
	}
	public void acceptBulkProductsDetails(ArrayList<Product> products) {
		products.forEach((product)->productDAO.save(product));
	}
	public void removeProdcutDetails(int productId)throws ProductDetailsNotFoundException{
		productDAO.delete(this.getProductDetails(productId));
		//productDAO.deleteById(productId);
	}
}