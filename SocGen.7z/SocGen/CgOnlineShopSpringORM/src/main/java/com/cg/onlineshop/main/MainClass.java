package com.cg.onlineshop.main;

import java.util.ArrayList;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.env.SystemEnvironmentPropertySource;

import com.cg.onlineshop.beans.Product;
import com.cg.onlineshop.daoservices.ProductDAOImpl;
import com.cg.onlineshop.exceptions.ProductDetailsNotFoundException;
import com.cg.onlineshop.services.ProductCatlogServices;

public class MainClass {
	public static void main(String[] args) {
		try {
			ApplicationContext context = new ClassPathXmlApplicationContext("onlineShopBean.xml");
			ProductCatlogServices services =(ProductCatlogServices)context.getBean("productCatlogServices");

			System.out.println("=====================Insert========================");
			Product product=services.acceptProductDetails(new Product(15000, 5, "Good Product", "Pen"));

			System.out.println("=====================get Product Details valid product ID==================");
			System.out.println(services.getProductDetails(product.getProductId()));
			
			System.out.println("=====================get Product Details Invalid Id==================");
			//System.out.println(services.getProductDetails(1455));
			System.out.println("=====================Get All Product Details======================");
			services.acceptProductDetails(new Product(15000, 5, "Good Product", "Pen"));
			services.getAllProductDetails().forEach(System.out::println);
			
			ArrayList<Product> productList = new ArrayList<>();
			productList.add(new Product(15000, 5, "Good Product", "Pen"));
			productList.add(new Product(15000, 5, "Good Product", "Pen"));
			productList.add(new Product(15000, 5, "Good Product", "Pen"));
			productList.add(new Product(15000, 5, "Good Product", "Pen"));
			productList.add(new Product(15000, 5, "Good Product", "Pen"));
			productList.add(new Product(15000, 5, "Good Product", "Pen"));
			
			services.acceptBulkProductsDetails(productList);
			
			System.out.println("=====================Get All Product Details======================");
			
			services.getAllProductDetails().forEach(System.out::println);
			
			
		} catch (ProductDetailsNotFoundException e) {

			e.printStackTrace();
		}

	}
}