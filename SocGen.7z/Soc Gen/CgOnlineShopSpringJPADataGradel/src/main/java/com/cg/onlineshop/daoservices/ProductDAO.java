package com.cg.onlineshop.daoservices;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cg.onlineshop.beans.Product;
public interface ProductDAO  extends JpaRepository<Product, Integer>{
	/*public void insertProduct(Product product);
	public void updateProduct(Product product);
	public void deleteProduct(int productId);
	public List<Product> getAllProducts();
	public Optional<Product> getProduct(int productId);
	void insertBulkProducts(ArrayList<Product>products);*/
	@Query(value="")
	List<Product> getAllProductsNameStartWith(String name);
}
