import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import com.cg.project.beans.Employee;
public class MainClass {
	public static void main(String[] args) {
		ArrayList<Employee> empList = new ArrayList<>();
		empList.add(new Employee(101, 15000, "Satish", "Mahajan"));
		empList.add(new Employee(102, 13884, "Ravi", "Mahajan"));
		empList.add(new Employee(104, 12000, "Jay", "Mahajan"));
		empList.add(new Employee(103, 54000, "Kunal", "Mahajan"));
		empList.add(new Employee(106, 23000, "Manish", "Mahajan"));
		empList.add(new Employee(105, 32323, "Rakesh", "Mahajan"));
		toListWork(empList);
		System.out.println("================================");
		toSetWork(empList);
		System.out.println("================================");
		toMapWork(empList);
		System.out.println("================================");
		flatMapWork();
		System.out.println("================================");
		summingWork(empList);
	}

	private static void toListWork(List<Employee> empList) {
		List<String>empNameList = empList.stream().map((e)->e.getFirstName()).collect(Collectors.toList());
		System.out.println(empNameList);
	}

	private static void toSetWork(List<Employee> empList) {
		Set<String>empNameSet = empList.stream().map((e)->e.getFirstName()).collect(Collectors.toSet());
		System.out.println(empNameSet);
	}
	private static void toMapWork(List<Employee> empList) {
		Map<Integer,String>empMap = empList.stream().collect(Collectors.toMap(Employee::getId,Employee::getFirstName));
		System.out.println(empMap);
	}
	private static void flatMapWork() {
		List<String[]>stringArrayList = new ArrayList<>();
		stringArrayList.add(new String[]{"ABC","XYZ","PQR"});
		stringArrayList.add(new String[]{"Satish","Rajesh"});
		stringArrayList.add(new String[]{"ABC","LMN"});
		stringArrayList.add(new String[]{"Amay","Araoh"});
		stringArrayList.add(new String[]{"Kumar","Alaokh"});

		Stream<String>stringStream= stringArrayList.stream().flatMap((x)->Arrays.stream(x));
		stringStream.forEach(System.out::println);
	}

	private static void summingWork(List<Employee>empList) {
		Double doubleRef= empList.stream().collect(Collectors.summingDouble(e->e.getSalary()));
		System.out.println(doubleRef);
		
		Integer intRef= empList.stream().collect(Collectors.summingInt(e->e.getSalary()));
		System.out.println(intRef);
	}

}
