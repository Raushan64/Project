package com.cg.payroll;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;
import com.cg.payroll.services.PayrollServiceImpl;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.utils.PayrollUtils;
import junit.framework.TestCase;

public class PayrollServicesTest extends TestCase{
	  private static PayrollServices payrollServices ;
	
	  @BeforeClass
	  public static void setUpEnv() {
		  payrollServices = new PayrollServiceImpl();
	  }
	  @Before
	  public void setUpTestEnv() {
		  Associate associate1 = new Associate(PayrollUtils.getASSOCIATE_ID_COUNTER(), 100000, "Satish", "Mahajan", "YTP", "SR Con", "AJJDJK763", "satish@capgemini.com", new Salary(15000, 1000, 1000), new BankDetails(1111, "HDFC", "hdfc009"));
		  PayrollUtils.associates.put(associate1.getAssociateID(), associate1);  
	  }
	  @Test(expected= AssociateDetailsNotFoundException.class)
	  public void testGetAssociateDetailsForInvalidId() throws AssociateDetailsNotFoundException, PayrollServicesDownException {
		  payrollServices.getAssociateDetails(66363);
	  }
	  
	  @Test
	  public void testGetAssociateDetailsForValidId() throws AssociateDetailsNotFoundException, PayrollServicesDownException {
		  Associate expectedAssociate = new Associate(PayrollUtils.getASSOCIATE_ID_COUNTER(), 100000, "Satish", "Mahajan", "YTP", "SR Con", "AJJDJK763", "satish@capgemini.com", new Salary(15000, 1000, 1000), new BankDetails(1111, "HDFC", "hdfc009"));
		  Associate actualAssociate=payrollServices.getAssociateDetails(101);
		  Assert.assertEquals(expectedAssociate, actualAssociate);
	  }
	  
	  @After
	  public void  tearDownTestEnv() {
		  PayrollUtils.ASSOCIATE_ID_COUNTER=101;
		  PayrollUtils.associates.clear();
	  }
	  
	  
	  @AfterClass 
	  public static void  tearDownEnv() {
		  payrollServices =null;
	  }
}