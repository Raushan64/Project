package com.cg.payroll.daoservices;
import java.util.List;
import com.cg.payroll.beans.Associate;
public class AssociateDAOImpl  implements AssociateDAO {

	public Associate save(Associate associate) {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean update(Associate associate) {
		// TODO Auto-generated method stub
		return false;
	}

	public Associate findOne(int associateId) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Associate> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

}