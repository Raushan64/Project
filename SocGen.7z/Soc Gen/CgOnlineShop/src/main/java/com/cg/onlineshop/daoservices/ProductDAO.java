package com.cg.onlineshop.daoservices;
import java.util.ArrayList;
import com.cg.onlineshop.beans.Product;
public interface ProductDAO {
	public void insertProduct(Product product);
	public void updateProduct(Product product);
	public void deleteProduct(int productId);
	public ArrayList<Product> getAllProducts();
	public Product getProduct(int productId);
	void insertBulkProducts(ArrayList<Product>products);
	
}
