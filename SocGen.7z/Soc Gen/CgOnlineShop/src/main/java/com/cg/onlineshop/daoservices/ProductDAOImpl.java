package com.cg.onlineshop.daoservices;

import java.util.ArrayList;

import com.cg.onlineshop.beans.Product;

public class ProductDAOImpl  implements ProductDAO{

	@Override
	public void insertProduct(Product product) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateProduct(Product product) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteProduct(int productId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public ArrayList<Product> getAllProducts() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Product getProduct(int productId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void insertBulkProducts(ArrayList<Product> products) {
		// TODO Auto-generated method stub
		
	}

	
}
