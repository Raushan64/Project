package com.cg.onlineshop.services;
import java.util.ArrayList;
import com.cg.onlineshop.beans.Product;
import com.cg.onlineshop.daoservices.ProductDAO;
import com.cg.onlineshop.exceptions.ProductDetailsNotFoundException;
public class ProductCatlogServicesImpl implements ProductCatlogServices{
	private ProductDAO productDAO;

	public Product acceptProductDetails(Product product) {
		return null;
	}

	public ArrayList<Product> getAllProductDetails() {
		// TODO Auto-generated method stub
		return null;
	}

	public Product getProductDetails(int productId) throws ProductDetailsNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	public void acceptBulkProductsDetails(ArrayList<Product> products) {
		// TODO Auto-generated method stub
		
	}

	public void removeProdcutDetails(int productId) {
		// TODO Auto-generated method stub
		
	}
	
	
	

}
