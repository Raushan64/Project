package com.cg.onlineshop.controllers;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;
import com.cg.onlineshop.beans.Product;
import com.cg.onlineshop.services.ProductCatlogServices;

@Controller
public class ProductCatlogServicesController {
	
	@Autowired
	private Validator validator;
	
	@Autowired 
	private ProductCatlogServices catlogServices;
	
	@PostMapping(value="/addProduct")
	public ModelAndView addProduct(@Valid @ModelAttribute Product product,BindingResult result) {
		validator.validate(product, result);
		if(result.hasErrors()) return new ModelAndView("acceptProductDetails");
		product = catlogServices.acceptProductDetails(product);
		return new ModelAndView("productSuccessPage","product",product);
	}
}
