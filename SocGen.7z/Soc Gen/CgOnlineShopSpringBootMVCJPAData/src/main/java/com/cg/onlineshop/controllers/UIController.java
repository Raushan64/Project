package com.cg.onlineshop.controllers;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;

import com.cg.onlineshop.beans.Product;
import com.fasterxml.jackson.annotation.JsonCreator.Mode;
@Controller
public class UIController {
	@GetMapping("/")
	public String getIndexPage() {
		System.out.println("getIndexPage()");
		return "indexPage";
	}
	@GetMapping("/acceptProductDetails")
	public String getHomePage() {
		return "acceptProductDetails";
	}
	@ModelAttribute("product")
	private Product getProduct() {
		return new Product();
	}
}