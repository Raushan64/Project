package com.cg.onlineshop.daoservices;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.cg.onlineshop.beans.Product;

@Repository(value="productDAO")
public class ProductDAOImpl  implements ProductDAO{

	@Autowired
	EntityManagerFactory factory;
	@Override
	public void insertProduct(Product product) {		
		EntityManager manager = factory.createEntityManager();
		manager.getTransaction().begin();
		manager.persist(product);
		manager.getTransaction().commit();
		manager.close();
	}

	@Override
	public void updateProduct(Product product) {
		EntityManager manager = factory.createEntityManager();
		manager.getTransaction().begin();
		manager.merge(product);
		manager.getTransaction().commit();
		manager.close();
	}

	@Override
	public void deleteProduct(int productId) {
		EntityManager manager = factory.createEntityManager();
		manager.getTransaction().begin();
		Product product = manager.find(Product.class, productId);
		manager.remove(product);
		manager.getTransaction().commit();
		manager.close();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Product> getAllProducts() {
		Query query =  factory.createEntityManager().createQuery("select p from Product p ");
		return query.getResultList();
	}

	@Override
	public Optional<Product> getProduct(int productId) {
		EntityManager entityManager = factory.createEntityManager();
		Product product = entityManager.find(Product.class, productId);
		Optional<Product> optional =Optional.ofNullable(product);
		return optional;
	}

	@Override
	public void insertBulkProducts(ArrayList<Product> products) {
		products.forEach((product)->this.insertProduct(product));		
	}
}
