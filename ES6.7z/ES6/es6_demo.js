function display(){
//let vs var
//let scope is block
//var scope is function

    var num=12;
    if(num>0){

        let name="kumar"
        var city="bangaore"
    }
    console.log(name)
    console.log(city)
    document.write(name+"<br>")
    document.write(city)
}
display()




//rest parameter
function print( a, b, ...c){
    document.write("<br>" +a+ "<br>"+ b +"<br>"+c)
}

//rest parameter must be the last parameter
 print(2,4,4,6,7)




//default parameter
function wishCustomer(msg="hello"){
    alert(msg)
} 
//calling function with parameter
wishCustomer();

wishCustomer('hi, good afternoon');




//spread operator
function show(){

    let num1=[1,2,3,4,5]
    let num2=[3,4,5,6]
    let num3=[...num1, ...num2]
    alert(num3)
}
show();




let skills=['java', 'spring', 'hibernate']

//let a=skills[0]
//let b=skills[1]

//destructuring assignment -> new feature of ES6
let[a,b]=skills;
document.write("<br>"+a+"<br>"+b)




//template literal
//backticks
document.write(`<br> ${a} <br> ${b}`)




//JS Object
//Number
//String
//Boolean
//Math
//Array --sort, reverse
//Object
skills.sort()
alert(skills)
alert("decending:"+ skills.sort().reverse())


let products=[
    {id:1, name:'kumar', price:22},
    {id:2, name:'sintu', price:60},
    {id:3, name:'pintu', price:56}

]

//products.sort()

products.sort((a,b)=>{
    if(a.price>b.price) return 1;
    else if(a.price<b.price) return -1;
    else return 0;
}).forEach(p=>document.write(`<br> ${p.id} <br> ${p.name} <br> ${p.price}`))



//Array filter
let fa= skills.filter(a=>a.toLocaleLowerCase().startsWith('s'))
alert(fa)

let fa1=products.filter(a=>a.name.startsWith('k'))



//arrow function
setTimeout(function (){

    alert('hai')
},3000)

setTimeout(()=> alert('hai'), 3000)

