package com.cg.onlineshop;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class OnlineShopRestFulSpringBootApplication {
	public static void main(String[] args) {
		SpringApplication.run(OnlineShopRestFulSpringBootApplication.class, args);
	}
}
