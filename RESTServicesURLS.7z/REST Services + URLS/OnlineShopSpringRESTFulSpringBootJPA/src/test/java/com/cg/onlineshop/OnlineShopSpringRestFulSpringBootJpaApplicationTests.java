package com.cg.onlineshop;
import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;
@SpringBootTest
class OnlineShopSpringRestFulSpringBootJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
