package com.cg.onlineshop.validators;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import com.cg.onlineshop.beans.Product;
@Component(value="validator")
public class PorductCustomValidator implements Validator{
	@Override
	public boolean supports(Class clazz) {
		return  Product.class.isAssignableFrom(clazz);
	}
	@Override
	public void validate(Object target, Errors errors) {
		ValidationUtils.rejectIfEmpty(errors, "productName", "productName.NotEmpty");
	}
}
