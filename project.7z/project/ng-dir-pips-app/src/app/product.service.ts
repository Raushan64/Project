import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  products  =[{name:"apple", id:1, price:12},
              {name:"banana", id:2, price:9},
              {name:"orange", id:3, price:15}
]

/*
getAllProduct(){
  return this.products;
}*/

 getAllProduct(){
   return this.http.get("http://localhost:3000/products");
 } 

 addProduct(product){
  let header=new HttpHeaders({'content-type':'application/json  '})
  return this.http.post("http://localhost:3000/products",product,{ headers :header } ); 
 }
  
 updateProduct(product){
  let header=new HttpHeaders({'content-type':'application/json'})
  return this.http.put("http://localhost:3000/products/"+product.id ,product, { headers :header } ); 
 }

 deleteProduct(pid){
  return this.http.delete("http://localhost:3000/products/"+pid); 
 }



  constructor(private http:HttpClient) { }
  // constructor() { }
}
