import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
   
  product
  products  
 
  constructor( private ps: ProductService) { }

  add(){
  let p ={name:'pen', price:12}
  this.ps.addProduct(p).subscribe(()=>{
    alert('added..')
    history.go()
  })
  
}

update(){
  let p ={ id:3, name:'pencil', price:11}
  this.ps.updateProduct(p).subscribe(()=>{
    alert('updated..')
    history.go()
  })
  
}

 remove(){

  this.ps.deleteProduct(4).subscribe(()=>{
    alert('deleted..')
    history.go()
  })

 }


  ngOnInit(): void {
  this.ps.getAllProduct().subscribe(res=>this.products=res);
  //this.products = this.ps.getAllProduct();
  }

}
