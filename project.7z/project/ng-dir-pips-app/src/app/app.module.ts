import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule} from '@angular/forms'
import {HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AttrDirectivesDemoComponent } from './attr-directives-demo/attr-directives-demo.component';
import { InBuildPipesDemoComponent } from './in-build-pipes-demo/in-build-pipes-demo.component';
import { FilterPipe } from './filter.pipe';
import { FilterSkillsComponent } from './filter-skills/filter-skills.component';
import { ProductListComponent } from './product-list/product-list.component';
import { ProductFilterPipe } from './product-filter.pipe';

@NgModule({
  declarations: [
    AppComponent,
    AttrDirectivesDemoComponent,
    InBuildPipesDemoComponent,
    FilterPipe,
    FilterSkillsComponent,
    ProductListComponent,
    ProductFilterPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
