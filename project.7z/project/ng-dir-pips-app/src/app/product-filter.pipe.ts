import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'productFilter'
})
export class ProductFilterPipe implements PipeTransform {

  transform(value: any , args: any): any {
    let fa=[];
    if(args.length!=0){
    value.forEach(element => {
        if(element.name.indexOf(args) != -1){
        fa.push(element)
        }
        else if(element.id == args){
          fa.push(element)
        }
        else if(element.price == args){
            fa.push(element)
        }
      }
    );
    
    return fa;
  }
}

}
