import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-attr-directives-demo',
  templateUrl: './attr-directives-demo.component.html',
  styleUrls: ['./attr-directives-demo.component.css']
})
export class AttrDirectivesDemoComponent implements OnInit {

  customStyle={ color: 'red', background:'blue'}

  flage=false

  toggle(){

    this.flage=!this.flage
  }


  constructor() { }

  ngOnInit(): void {
  }

}
