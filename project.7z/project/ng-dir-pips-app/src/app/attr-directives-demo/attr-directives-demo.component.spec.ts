import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AttrDirectivesDemoComponent } from './attr-directives-demo.component';

describe('AttrDirectivesDemoComponent', () => {
  let component: AttrDirectivesDemoComponent;
  let fixture: ComponentFixture<AttrDirectivesDemoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AttrDirectivesDemoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AttrDirectivesDemoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
