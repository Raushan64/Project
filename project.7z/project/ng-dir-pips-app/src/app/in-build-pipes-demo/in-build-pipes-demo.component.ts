import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-in-build-pipes-demo',
  templateUrl: './in-build-pipes-demo.component.html',
  styleUrls: ['./in-build-pipes-demo.component.css']
})
export class InBuildPipesDemoComponent implements OnInit {

  userName="Raushan"
  orgName="CAPGEMINI"
  salary= 44977
  doj=new Date()
  id=1110775
  num=123.349
  hike=0.09

  constructor() { }

  ngOnInit(): void {
  }

}
