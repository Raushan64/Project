import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InBuildPipesDemoComponent } from './in-build-pipes-demo.component';

describe('InBuildPipesDemoComponent', () => {
  let component: InBuildPipesDemoComponent;
  let fixture: ComponentFixture<InBuildPipesDemoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InBuildPipesDemoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InBuildPipesDemoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
