import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-filter-skills',
  templateUrl: './filter-skills.component.html',
  styleUrls: ['./filter-skills.component.css']
})
export class FilterSkillsComponent implements OnInit {


 skill;  
 skills=["java", "spring", "hibernate", "scala" ,"angular", "node", "servlet"]

  constructor() { }

  ngOnInit(): void {
  }

}
