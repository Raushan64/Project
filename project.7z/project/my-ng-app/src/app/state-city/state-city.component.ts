import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-state-city',
  templateUrl: './state-city.component.html',
  styleUrls: ['./state-city.component.css']
})
export class StateCityComponent implements OnInit {

 state =["karanatka", "taminladu", "andhrapradesh"]
 s1

 karanatka =[ "bagalore", "masore"]
 taminladu =[ "chennai", "koyembatoor"]
 andhrapradesh =[ "vga", "gtr"]


  constructor() { }

  ngOnInit(): void {
  }

}
