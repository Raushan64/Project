import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DemoComponent } from './demo/demo.component';
import { EmployeeComponent } from './employee/employee.component';
import {FormsModule} from '@angular/forms';
import { TodoComponent } from './todo/todo.component';
import { LanguageDescriptionComponent } from './language-description/language-description.component';
import { StateCityComponent } from './state-city/state-city.component';
import { CategoryProductComponent } from './category-product/category-product.component';
import { EmiCalculatorComponent } from './emi-calculator/emi-calculator.component';

@NgModule({
  declarations: [
    AppComponent,
    DemoComponent,
    EmployeeComponent,
    TodoComponent,
    LanguageDescriptionComponent,
    StateCityComponent,
    CategoryProductComponent,
    EmiCalculatorComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
