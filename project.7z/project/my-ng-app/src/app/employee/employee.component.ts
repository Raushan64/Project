import { Component, OnInit } from '@angular/core';
import { Product } from '../product';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

  empName : string ="kumar"
  id : number=1234
  salary :number =2000
  isEmplopyee: boolean=true
 skills: string[]=["java", "hibernate", "spring"]

  products : Product[]=[
         {id:1, name:"apple", price:12},
         {id:2, name:"orange", price:14},
         {id:3, name:"banana", price:17}
 ]
  
  wishEmployee(){
    alert("hello employee")
  }
  

  username="sandeep"
  //number of ticket
  NOT = 1;

  constructor() { }

  ngOnInit(): void {
  }

}
