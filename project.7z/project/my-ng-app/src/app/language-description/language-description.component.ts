import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-language-description',
  templateUrl: './language-description.component.html',
  styleUrls: ['./language-description.component.css']
})
export class LanguageDescriptionComponent implements OnInit {


langs=["java", "angular", "scala"]

lang


  constructor() { }

  ngOnInit(): void {
  }

}
