import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {


  constructor(private router: Router) { }

  ngOnInit(): void {
  }

  userName
  pass

  login(){
     localStorage.setItem('user', this.userName)
    if(this.userName=='raushan' && this.pass=='kumar'){
      localStorage.setItem('role', 'admin')
    }else{
      localStorage.setItem('role', 'user')
    }
   this.router.navigate(['home'])

  }

}
