import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class ProductService {

  constructor(private http: HttpClient){}

  getAllProduct(){
    return this.http.get("http://localhost:3000/products")
  }

  addProduct(product){
    let header=new HttpHeaders({'content-type': 'application/json'})
    return this.http.post("http://localhost:3000/products",product, {headers:header})
  }

  updateProduct(product){
    let header=new HttpHeaders({'content-type': 'application/json'})
    return this.http.put("http://localhost:3000/products/"+product.id, product, {headers:header})
  }


  deleteProduct(id){
    return this.http.delete("http://localhost:3000/products/"+id)
  }

}
