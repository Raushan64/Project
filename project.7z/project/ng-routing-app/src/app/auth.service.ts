import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

 isAuthorized(allowedRoles: string[]): boolean {
   if(allowedRoles == null || allowedRoles.length == 0 ){
     return true;
   }
   return allowedRoles.includes(localStorage.getItem('role'));
 }

  constructor() { }
}
