import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {

  product
  constructor(private ps:ProductService, private route: Router) {
    this.product=history.state;
   }

   update(){

    this.ps.updateProduct(this.product).subscribe(()=>{
alert('updated...')
this.route.navigate(['products'])

    })
   }

  ngOnInit(): void {
  }

}
