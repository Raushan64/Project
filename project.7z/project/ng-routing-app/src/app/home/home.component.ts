import { Component, OnInit } from '@angular/core';
import { Route } from '@angular/compiler/src/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  
  userName
  constructor(private route: Router) { }

  logout(){
    localStorage.clear()
    this.route.navigate([''])
  }

  ngOnInit(): void {
    this.userName=localStorage.getItem('user')
  }

}
