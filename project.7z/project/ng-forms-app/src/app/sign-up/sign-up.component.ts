import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit {
  user
  pass
  skill
  gender
  cb1
  cb3
  cb2
 skills=["java", "spring", "hibernate"]


  constructor() { }

  ngOnInit(): void {
  }

}
