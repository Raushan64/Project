package com.cg.onlineshop.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.cg.onlineshop.beans.Product;
import com.cg.onlineshop.daoservices.ProductDAO;
import com.cg.onlineshop.daoservices.ProductDAOImpl;
import com.cg.onlineshop.exceptions.ProductDetailsNotFoundException;

public class ProductCatlogServicesImpl implements ProductCatlogServices {

	public ProductDAO productDAO = new ProductDAOImpl();

	public Product acceptProductDetails(Product product) {

		return productDAO.insertProduct(product);

	}

	public ArrayList<Product> getAllProductDetails() {

		return productDAO.getAllProducts();
	}

	public Product getProductDetails(int productId) throws ProductDetailsNotFoundException {
		
		Product product	=productDAO.getProduct(productId);
		if(product==null) {
			throw new ProductDetailsNotFoundException("Exception has occured for product details");
		}

		return productDAO.getProduct(productId);
		
	 //return productDAO.getProduct(productId).orElseThrow("product not found");
		
		
	}

	public List<Product> acceptBulkProductsDetails(List<Product> array) {

		return productDAO.insertBulkProducts(array);
	}

	public boolean removeProdcutDetails(int productId) {
		return productDAO.deleteProduct(productId);

	}

}
