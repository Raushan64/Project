package com.cg.onlineshop.daoservices;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.cg.onlineshop.beans.Product;
public interface ProductDAO {
	public Product insertProduct(Product product);
	public void updateProduct(Product product);
	public boolean deleteProduct(int productId);
	public ArrayList<Product> getAllProducts();
	public Product getProduct(int productId);
	public List<Product> insertBulkProducts(List<Product>products);
	
}
