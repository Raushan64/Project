package com.cg.onlineshop.main;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.omg.CORBA.portable.ApplicationException;
import org.springframework.context.ApplicationContext;

import com.cg.onlineshop.beans.Product;
import com.cg.onlineshop.exceptions.ProductDetailsNotFoundException;
import com.cg.onlineshop.services.ProductCatlogServicesImpl;

public class MainClass {

	public static void main(String[] args) throws ProductDetailsNotFoundException {
		
		ProductCatlogServicesImpl pcimp = new ProductCatlogServicesImpl();
		
		// insert
		Product pd1 = new Product(1, 30000, 20000, "Product1", "IPhone7");
		Product pd2 = new Product(2, 40000, 20000, "Product2", "IPhone8");
		Product pd3 = new Product(3, 50000, 20000, "Product3", "IPhone9");
		Product product = pcimp.acceptProductDetails(pd1);
		System.out.println("inserted product :"+product);
		System.out.println("=====");

		// getAllDetails
		ArrayList<Product> arry = pcimp.getAllProductDetails();

		for (Product p : arry) {

			System.out.println("product all details :" + p);
		}

		System.out.println("=====");

		// getProductDetails
		try {
			Product p = pcimp.getProductDetails(pd1.getProductId());
			System.out.println(p);
		} catch (ProductDetailsNotFoundException e) {
			e.printStackTrace();
		}

		System.out.println("======");

		// acceptBulkProductsDetails
		List<Product> array = new ArrayList<Product>();
		array.add(pd1);
		array.add(pd2);
		array.add(pd3);
		List<Product> listProduct = pcimp.acceptBulkProductsDetails(array);

		for (Product pp : listProduct) {
			System.out.println(pp);
		}

		// remove
		// boolean b= pcimp.removeProdcutDetails(pd.getProductId());
		// System.out.println(b);

	}
}
