package com.cg.onlineshop.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.cg.onlineshop.beans.Product;
import com.cg.onlineshop.exceptions.ProductDetailsNotFoundException;

public interface ProductCatlogServices {
	public Product acceptProductDetails(Product product);
	public ArrayList<Product> getAllProductDetails();
	public Product getProductDetails(int productId) throws ProductDetailsNotFoundException;
	public List<Product> acceptBulkProductsDetails(List<Product> products);
	public boolean removeProdcutDetails(int productId);
}
