package com.cg.onlineshop.daoservices;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.cg.onlineshop.beans.Product;
import com.cg.util.Test;

public class ProductDAOImpl implements ProductDAO {

	public Product insertProduct(Product product) {

		Test.map.put(product.getProductId(), product);
		return Test.map.get(product.getProductId());

	}

	public void updateProduct(Product product) {
		// TODO Auto-generated method stub

	}

	public boolean deleteProduct(int productId) {

		if (Test.map.containsKey(productId)) {
			Test.map.remove(productId);
			return true;
		}

		return false;
	}

	public ArrayList<Product> getAllProducts() {
		ArrayList<Product> listOfProducts = new ArrayList<Product>(Test.map.values());
		return new ArrayList<Product>(Test.map.values());
	}

	public Product getProduct(int productId) {

		return Test.map.get(productId);
	}

	public List<Product> insertBulkProducts(List<Product> products) {

		for (Product p : products)
			Test.map.put(p.getProductId(), p);

		return new ArrayList<Product>(Test.map.values());

	}

}
