package com.cg.util;

import java.util.HashMap;
import java.util.Map;

import com.cg.onlineshop.beans.Product;

public class Test {

	public static HashMap<Integer, Product> map=new HashMap<Integer,Product >();
 
}