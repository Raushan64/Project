import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  constructor(private http: HttpClient) { }

  getAllProducts() {
    return this.http.get("http://localhost:9090/all")
  }

  addProduct(product) {
    //let header = new HttpHeaders({ 'content-type': 'application/json' })
    return this.http.post(" http://localhost:9090/add", product);//, { headers: header })
  }

  updateProduct(product) {
    let header = new HttpHeaders({ 'content-type': 'application/json' })
    return this.http.put("http://localhost:3000/products/" + product.id, product, { headers: header })
  }

  deleteProduct(id) {
    return this.http.delete("http://localhost:3000/products/" + id)
  }
}
