import { ProductService } from './../product.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {

  product = { id: '', name: '', price: '' }

  add() {

    this.ps.addProduct(this.product).subscribe(() => {
      alert('added...')
      this.router.navigate(['products'])
    })
  }
  constructor(private ps: ProductService, private router: Router) { }

  ngOnInit() {
  }

}
