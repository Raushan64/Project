import { AuthGuard } from './auth.guard';
import { LoginComponent } from './login/login.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { AboutComponent } from './about/about.component';
import { HomeComponent } from './home/home.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProductListComponent } from './product-list/product-list.component';
import { AddComponent } from './add/add.component';
import { UpdateComponent } from './update/update.component';

const routes: Routes = [
  {
    path: '',
    canActivateChild: [AuthGuard],
    children: [
      { path: '', component: LoginComponent, data: {} },
      { path: 'home', component: HomeComponent, data: { 'roles': ['admin', 'user'] } },
      { path: 'about', component: AboutComponent, data: { 'roles': ['admin', 'user'] } },
      { path: 'products', component: ProductListComponent, data: { 'roles': ['admin', 'user'] } },
      { path: 'add', component: AddComponent, data: { 'roles': ['admin'] } },
      { path: 'update', component: UpdateComponent, data: { 'roles': ['admin'] } },
      { path: '**', component: PageNotFoundComponent }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
