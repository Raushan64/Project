import { Component } from "@angular/core";
import { IProduct } from "./Product";
import { sharedStylesheetJitUrl } from "@angular/compiler";
import { OnInit } from "@angular/core/src/metadata/lifecycle_hooks";
import { ProductService } from "./product.service";

@Component({
    selector:'pm-products',
    templateUrl:'./product-list.component.html',
    styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit{
    productListTitle:string='Products List!!!*** ';
    imageWidth:number=50;
    imageMargin:number=2;
    showImage:boolean=false;
    errorMessage:string;
    _listFilter: string;
    filteredProducts: IProduct[];
    products:IProduct[];

    constructor(private _productSerevice:ProductService){
        this.listFilter='';
    }
    get listFilter(): string {
        return this._listFilter;
    }
    set listFilter(value: string) {
        this._listFilter = value;
        this.filteredProducts = this.listFilter ? this.performFilter(this.listFilter) : this.products;
    }
    ngOnInit():void{
        
      
        this.filteredProducts=this.products;

        this._productSerevice.getProducts()
        .subscribe(products=>{
            this.products=products
            this.filteredProducts=this.products;
        },
        error=>this.errorMessage=error)

    }
    toggleImage():void{
        this.showImage =! this.showImage;
    }

  

    performFilter(filterBy: string): IProduct[] {
        filterBy = filterBy.toLocaleLowerCase();
        return this.products.filter((product: IProduct) =>
              product.productName.toLocaleLowerCase().indexOf(filterBy) !== -1);
    }  

    onRatingClicked(message:string):void{
        console.log("************************838383*********");
        this.productListTitle="Products List!!! "+ message;
    }
}